import { Box } from '@mui/material'
import React from 'react'

function CallCenter() {
  return (
    <Box sx={{position:"relative",top:"8rem",}}><h1>Call Center</h1></Box>
  )
}

export default CallCenter