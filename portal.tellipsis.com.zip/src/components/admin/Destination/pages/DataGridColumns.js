import React from "react";
import { Typography, IconButton, TextField, InputAdornment } from "@mui/material";
import { Edit } from "@mui/icons-material";
import { getGridStringOperators } from "@mui/x-data-grid";
import ClearIcon from "@mui/icons-material/Clear";


function MultiValueInput(props) {
  const { item, applyValue, focusElementRef } = props;

  const handleChange = (e) => {
    const raw = e.target.value;

    const values = raw
      .split(/[\s,]+/) // space, comma, newline
      .map((v) => v.trim())
      .filter(Boolean);

    applyValue({ ...item, value: values });
  };

  const handleClear = () => {
    applyValue({ ...item, value: [] });
  };

  return (
    <TextField
      inputRef={focusElementRef}
      className="multiValueFilterInput"
      value={Array.isArray(item.value) ? item.value.join(", ") : ""}
      onChange={handleChange}
      placeholder="Enter numbers separated by space or comma"
      variant="standard"
      fullWidth
      InputProps={{
        endAdornment: item?.value?.length ? (
          <InputAdornment position="end">
            <IconButton
              edge="end"
              size="small"
              onClick={handleClear}
              sx={{
                color: "#9CA3AF",
                "&:hover": { color: "#DC2626" },
              }}
            >
              <ClearIcon />
            </IconButton>
          </InputAdornment>
        ) : null,
      }}
    />
  );
}


export const columns = ({ isMobile, isXs, user, handleEdit }) => [
  {
    field: "action",
    headerName: "Action",
    headerClassName: "custom-header",
    headerAlign: "center",
    align: "center",
    sortable: false,
    width: 50,
    renderCell: (params) => (
      user.user_role !== "Reseller" && (
        <IconButton onClick={() => handleEdit(params.row)}>
          <Edit style={{ cursor: "pointer", color: "#0e397f" }} />
        </IconButton>
      )
    ),
  },
  {
  field: "tfn_number",
  headerName: "Destination",
  headerClassName: "custom-header",
  headerAlign: "center",
  align: "center",
  width: 150,
  filterOperators: getGridStringOperators().map((operator) => {
    if (operator.value === "isAnyOf") {
      return {
        ...operator,
        InputComponent: MultiValueInput,
        getApplyFilterFn: (filterItem) => {
          if (!Array.isArray(filterItem.value) || filterItem.value.length === 0) {
            return null;
          }

          return (params) => {
            if (params.value == null) return false;

            return filterItem.value.includes(String(params.value));
          };
        },
      };
    }
    return operator;
  }),
},
  {
    field: "username",
    headerName: "User",
    headerClassName: "custom-header",
    width: 100,
    headerAlign: "center",
    align: "center",
  },
  {
    field: "reseller_name",
    headerName: "Reseller",
    headerClassName: "custom-header",
    width: 100,
    headerAlign: "center",
    align: "center",
  },
  {
    field: "service_type",
    headerName: "Service",
    headerClassName: "custom-header",
    width: 80,
    headerAlign: "center",
    align: "center",
  },
  {
    field: "sub_type",
    headerName: "Sub Type",
    headerClassName: "custom-header",
    width: 100,
    headerAlign: "center",
    align: "center",
    renderCell: (params) => {
      const subType = params.row.sub_type?.toString()?.toLowerCase();
      const isExtension = subType === "extension";
      const isQueue = subType === "queue";
      
      if (!isExtension && !isQueue) return null;

      return (
        <div
          style={{
            color: "white",
            background: isExtension ? "cornflowerblue" : "blueviolet",
            padding: "7px",
            borderRadius: "5px",
            fontSize: "12px",
            textTransform: "capitalize",
          }}
        >
          {subType}
        </div>
      );
    },
  },
  {
    field: "details",
    headerName: "Details",
    headerClassName: "custom-header",
    width: 150,
    headerAlign: "center",
    align: "center",
  },
  {
    field: "recording",
    headerName: "Recording",
    headerClassName: "custom-header",
    width: 80,
    headerAlign: "center",
    align: "center",
    renderCell: (params) => (
      <div
        style={{
          color: params.row.recording ? "green" : "red",
          padding: "7px",
          borderRadius: "5px",
          fontSize: "12px",
          textTransform: "capitalize",
        }}
      >
        {params.row.recording ? "Yes" : "No"}
      </div>
    ),
  },
  {
    field: "description",
    headerName: "Description",
    headerClassName: "custom-header",
    width: 150,
    headerAlign: "left",
    align: "left",
  },
  {
    field: "carrier_name",
    headerName: "Carrier Name",
    headerClassName: "custom-header",
    width: 100,
    headerAlign: "left",
    align: "left",
  },
  {
    field: "created_date",
    headerName: "Create Date",
    headerClassName: "custom-header",
    width: 100,
    headerAlign: "center",
    align: "center",
    valueFormatter: (params) => {
      const date = new Date(params.value);
      return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
    },
  },
  {
    field: "updated_date",
    headerName: "Update Date",
    headerClassName: "custom-header",
    width: 100,
    headerAlign: "center",
    align: "center",
    valueFormatter: (params) => {
      const date = new Date(params.value);
      return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
    },
  },
  {
    field: "status",
    headerName: "Status",
    headerClassName: "custom-header",
    width: isXs ? 70 : 80,
    minWidth: 70,
    maxWidth: 80,
    headerAlign: "start",
    align: "start",
    renderHeader: () => (
      <Typography
        variant="body2"
        sx={{
          fontSize: "calc(0.6rem + 0.2vw)",
          fontWeight: "bold",
          color: "white !important",
        }}
      >
        Status
      </Typography>
    ),
    renderCell: (params) => {
      const { is_active, is_suspended } = params.row;
      const key = `${String(is_active)}_${String(is_suspended)}`;
      
      const labelMap = {
        1: { label: "Suspend", color: "orange" },
        Active_0: { label: "Active", color: "green" },
        Deactive_1: { label: "Suspend", color: "orange" },
        Deactive_0: { label: "Deactive", color: "red" },
      };

      const { label, color } = labelMap[key] || { label: "Suspend", color: "orange" };

      return (
        <div
          style={{
            color,
            padding: isMobile ? "5px" : "7px",
            borderRadius: "5px",
            textAlign: "center",
            fontSize: "calc(0.6rem + 0.2vw)",
          }}
        >
          {label}
        </div>
      );
    },
  },
];