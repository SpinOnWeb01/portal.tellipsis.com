import AdminDestination from './AdminDestination';

export default AdminDestination;